var header = document.getElementById('header__item')
var call = document.getElementById('call')
var menu = document.getElementById('menu__burger')
function header__active(){
    header.classList.toggle('header__active')
    call.classList.toggle('call__active')
    menu.classList.toggle('menu__active')
}
menu.addEventListener('click', header__active)

function onEntry(entry) {
    entry.forEach(change => {
        if (change.isIntersecting) {
        change.target.classList.add('why__us-active');
        }
    });
    }

let options = { threshold: [0.5] };
let observer = new IntersectionObserver(onEntry, options);
let elements = document.querySelectorAll('.title__why-us');
for (let elm of elements) {
observer.observe(elm);
}

function onEntry(entry) {
    entry.forEach(change => {
        if (change.isIntersecting) {
        change.target.classList.add('why__us-active');
        }
    });
    }

let options2 = { threshold: [0.5] };
let observer2 = new IntersectionObserver(onEntry, options2);
let elements2 = document.querySelectorAll('.title__about-us');
for (let elm of elements2) {
observer2.observe(elm);
}


function onEntry(entry) {
    entry.forEach(change => {
        if (change.isIntersecting) {
        change.target.classList.add('why__us-active');
        change.target.classList.add('header__item-active');
        }
    });
    }

let options3 = { threshold: [0.5] };
let observer3 = new IntersectionObserver(onEntry, options3);
let elements3 = document.querySelectorAll('.header__item');
for (let elm of elements3) {
observer3.observe(elm);
}



function onEntry(entry) {
    entry.forEach(change => {
        if (change.isIntersecting) {
        change.target.classList.add('why__us-active');
        change.target.classList.add('header__item-active');
        change.target.classList.add('first__list-active');
        }
    });
    }

let options4 = { threshold: [0.5] };
let observer4 = new IntersectionObserver(onEntry, options4);
let elements4 = document.querySelectorAll('.first__list');
for (let elm of elements4) {
observer4.observe(elm);
}


function onEntry(entry) {
    entry.forEach(change => {
        if (change.isIntersecting) {
        change.target.classList.add('why__us-active');
        change.target.classList.add('header__item-active');
        change.target.classList.add('first__list-active');
        change.target.classList.add('second_list-active');
        }
    });
    }

let options5 = { threshold: [0.5] };
let observer5 = new IntersectionObserver(onEntry, options5);
let elements5 = document.querySelectorAll('.second__list');
for (let elm of elements5) {
observer5.observe(elm);
}


function onEntry(entry) {
    entry.forEach(change => {
        if (change.isIntersecting) {
        change.target.classList.add('why__us-active');
        change.target.classList.add('header__item-active');
        change.target.classList.add('first__list-active');
        change.target.classList.add('second_list-active');
        change.target.classList.add('last_list-active');
        }
    });
    }

let options6 = { threshold: [0.5] };
let observer6 = new IntersectionObserver(onEntry, options6);
let elements6 = document.querySelectorAll('.last__list');
for (let elm of elements6) {
observer6.observe(elm);
}


function onEntry(entry) {
    entry.forEach(change => {
        if (change.isIntersecting) {
        change.target.classList.add('why__us-active');
        change.target.classList.add('header__item-active');
        change.target.classList.add('first__list-active');
        change.target.classList.add('second_list-active');
        change.target.classList.add('last_list-active');
        change.target.classList.add('title__benefits-active');
        }
    });
    }

let options7 = { threshold: [0.5] };
let observer7 = new IntersectionObserver(onEntry, options7);
let elements7 = document.querySelectorAll('.title__benefits');
for (let elm of elements7) {
observer7.observe(elm);
}

function onEntry(entry) {
    entry.forEach(change => {
        if (change.isIntersecting) {
        change.target.classList.add('why__us-active');
        change.target.classList.add('header__item-active');
        change.target.classList.add('first__list-active');
        change.target.classList.add('second_list-active');
        change.target.classList.add('last_list-active');
        change.target.classList.add('title__benefits-active');
        change.target.classList.add('title__animation-active');
        }
    });
    }

let options8 = { threshold: [0.5] };
let observer8 = new IntersectionObserver(onEntry, options8);
let elements8 = document.querySelectorAll('.title__animation');
for (let elm of elements8) {
observer8.observe(elm);
}

function onEntry(entry) {
    entry.forEach(change => {
        if (change.isIntersecting) {
        change.target.classList.add('why__us-active');
        change.target.classList.add('header__item-active');
        change.target.classList.add('first__list-active');
        change.target.classList.add('second_list-active');
        change.target.classList.add('last_list-active');
        change.target.classList.add('title__benefits-active');
        change.target.classList.add('title__animation-active');
        change.target.classList.add('accordion__1-active');
        }
    });
    }

let options9 = { threshold: [0.5] };
let observer9 = new IntersectionObserver(onEntry, options9);
let elements9 = document.querySelectorAll('.accordion-1');
for (let elm of elements9) {
observer9.observe(elm);
}

function onEntry(entry) {
    entry.forEach(change => {
        if (change.isIntersecting) {
        change.target.classList.add('why__us-active');
        change.target.classList.add('header__item-active');
        change.target.classList.add('first__list-active');
        change.target.classList.add('second_list-active');
        change.target.classList.add('last_list-active');
        change.target.classList.add('title__benefits-active');
        change.target.classList.add('title__animation-active');
        change.target.classList.add('accordion__1-active');
        change.target.classList.add('accordion__none-active');
        }
    });
    }

let options10 = { threshold: [0.5] };
let observer10 = new IntersectionObserver(onEntry, options10);
let elements10 = document.querySelectorAll('.accordion__none');
for (let elm of elements10) {
observer10.observe(elm);
}

function onEntry(entry) {
    entry.forEach(change => {
        if (change.isIntersecting) {
        change.target.classList.add('why__us-active');
        change.target.classList.add('header__item-active');
        change.target.classList.add('first__list-active');
        change.target.classList.add('second_list-active');
        change.target.classList.add('last_list-active');
        change.target.classList.add('title__benefits-active');
        change.target.classList.add('title__animation-active');
        change.target.classList.add('accordion__1-active');
        change.target.classList.add('accordion__none-active');
        change.target.classList.add('form__item-active');
        }
    });
    }

let options11 = { threshold: [0.5] };
let observer11 = new IntersectionObserver(onEntry, options11);
let elements11 = document.querySelectorAll('.form__item');
for (let elm of elements11) {
observer11.observe(elm);
}

+function (){
    document.querySelector('.accordion__section').classList.add('opened')
    document.querySelectorAll('.accordion__section').forEach(function(section){
        section.addEventListener('click', function(e){
            document.querySelectorAll('.accordion__section').forEach(function(section){
                section.classList.remove('opened')
                e.target.closest('.accordion__section').classList.add('opened')
            })
        })
    })
}()
